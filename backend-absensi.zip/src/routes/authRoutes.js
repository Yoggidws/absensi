const express = require("express");
const { verifyToken, isAdmin } = require("../middlewares/authMiddleware");
const userController = require("../controllers/UserController");
const authController = require("../controllers/authController");
const { getSession } = require("../controllers/authController");


const router = express.Router();

router.get("/session", authController.getSession);
router.get("/", verifyToken, isAdmin, userController.getAllUsers); // Hanya admin bisa akses
router.post("/login", authController.login);

module.exports = router;
