// const express = require("express");
// const { generateQRCode, attendance } = require("../controllers/attendanceController");
// const attendanceController = require("../controllers/attendanceController");


// const router = express.Router();

// router.get("/qrcode", generateQRCode);
// // router.post("/scan", attendance);
// router.post("/scan", verifyToken, attendanceController.attendance); // Tambahkan verifyToken di sini


// module.exports = router;

const express = require("express");
const { verifyToken } = require("../middlewares/authMiddleware");
// const attendanceController = require("../controllers/attendanceController"); // Pastikan ini benar
const attendanceController = require("../controllers/attendanceController");

const router = express.Router();

router.get("/qrcode", attendanceController.generateQRCode);
router.post("/scan", verifyToken, attendanceController.attendance); // Gunakan controller yang benar
router.get("/getAttendanceAll", verifyToken, attendanceController.attendanceAll)

module.exports = router;
