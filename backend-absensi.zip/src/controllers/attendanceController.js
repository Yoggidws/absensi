
const { v4: uuidv4 } = require("uuid");
const QRCode = require("qrcode");
const db = require("../database/db");

// ✅ Generate QR Code dinamis
exports.generateQRCode = async (req, res) => {
  try {
    const qrId = uuidv4();
    const qrData = `attendance:${qrId}`;
    const qrImage = await QRCode.toDataURL(qrData);
    const expiryTime = new Date(Date.now() + 5 * 60 * 1000); // 5 menit

    await db.query("INSERT INTO qrcodes (id, expires_at) VALUES ($1, $2)", [qrId, expiryTime]);

    res.json({ qrId, qrImage, expiresAt: expiryTime });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Gagal membuat QR Code" });
  }
};





exports.attendance = async (req, res) => {
  try {
    const { qr_code } = req.body;
    const user_id = req.user?.id;

    if (!user_id) {
      return res.status(401).json({ message: "Unauthorized! User tidak ditemukan." });
    }

    if (!qr_code) {
      return res.status(400).json({ message: "QR Code wajib diisi!" });
    }

    // 🔹 Cek QR Code di database
    const qrResult = await db.query("SELECT * FROM qrcodes WHERE id = $1", [qr_code]);
    if (qrResult.rowCount === 0) {
      return res.status(400).json({ message: "QR Code tidak valid atau sudah kadaluarsa!" });
    }

    // 🔹 Cek apakah user sudah check-in hari ini
    const today = new Date().toISOString().split("T")[0];
    const attendanceResult = await db.query(
      "SELECT * FROM attendance WHERE user_id = $1 AND DATE(check_in) = $2",
      [user_id, today]
    );

    if (attendanceResult.rowCount === 0) {
      // ⏳ Jika belum check-in, simpan sebagai check-in
      await db.query("INSERT INTO attendance (user_id, check_in) VALUES ($1, NOW())", [user_id]);
      await db.query("DELETE FROM qrcodes WHERE id = $1", [qr_code]); // Hapus QR setelah dipakai
      return res.json({ message: "Check-in berhasil!" });
    }

    const attendance = attendanceResult.rows[0];
    if (attendance.check_out) {
      return res.status(400).json({ message: "Anda sudah check-in & check-out hari ini!" });
    }

    // ⏳ Jika sudah check-in tapi belum check-out, simpan sebagai check-out
    await db.query("UPDATE attendance SET check_out = NOW() WHERE id = $1", [attendance.id]);
    await db.query("DELETE FROM qrcodes WHERE id = $1", [qr_code]); // Hapus QR setelah dipakai
    res.json({ message: "Check-out berhasil!" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Gagal memproses absensi" });
  }
};

exports.attendanceAll = async (req, res) => {
  const isAdmin = req.user.role === 'admin'; // misalnya ambil dari token/jwt
  try {
    let result;
    if (isAdmin) {
      result = await db.query('SELECT * FROM attendance ORDER BY date DESC');
    } else {
      result = await db.query('SELECT * FROM attendance WHERE employee_id = ? ORDER BY date DESC', [req.user.id]);
    }

    res.json(result);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching attendance', error });
  }
}